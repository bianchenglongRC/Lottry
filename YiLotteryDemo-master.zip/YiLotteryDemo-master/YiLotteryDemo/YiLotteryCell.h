//
//  YiLotteryCell.h
//  YiLotteryDemo
//
//  Created by apple on 15/2/12.
//  Copyright (c) 2015年 coderyi. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface YiLotteryCell : UIImageView
@property UILabel *label;
@property UIImageView *titleImageView;
@end

//
//  main.m
//  YiLotteryDemo
//
//  Created by apple on 15/2/12.
//  Copyright (c) 2015年 coderyi. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "YiAppDelegate.h"

int main(int argc, char * argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([YiAppDelegate class]));
    }
}

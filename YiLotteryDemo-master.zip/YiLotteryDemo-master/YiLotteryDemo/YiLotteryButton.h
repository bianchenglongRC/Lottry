//
//  YiLotteryButton.h
//  YiLotteryDemo
//
//  Created by apple on 15/2/12.
//  Copyright (c) 2015年 coderyi. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface YiLotteryButton : UIButton
@property UIImageView *titleImageView;
@property UILabel *label;
@end

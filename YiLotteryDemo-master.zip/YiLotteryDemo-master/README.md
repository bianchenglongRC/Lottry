# YiLotteryDemo
模仿美团积分抽奖功能



![YiLotteryDemo](http://7u2k5i.com1.z0.glb.clouddn.com/github_YiLotteryDemo.png?imageMogr2/thumbnail/!50p) 


copyright (c) 2015 coderyi.all rights reserved.
